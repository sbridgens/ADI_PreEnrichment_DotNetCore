﻿namespace Application.Models
{
    public class AdiValidationResult
    {
        public bool IsQamAsset { get; set; }
        public string NewTitlPaid { get; set; }
        public string OnapiProviderid { get; set; }
    }
}