﻿namespace Domain.Entities
{
    public class CategoryMapping
    {
        public int Id { get; set; }
        public string ProviderId { get; set; }
        public string ProviderName { get; set; }
        public string CategoryValue { get; set; }
    }
}
